# shellcheck shell=bash
# shellcheck disable=SC2034

# validate_shell_type_and_version defined in shellspec/spec_helper.sh used to validate the expected shell type and version this script needs to run.
if ! validate_shell_type_and_version "bash" 4 &>/dev/null; then
  echo "redis_sentinel_member_leave_spec.sh skip all cases because dependency bash version 4 or higher is not installed."
  exit 0
fi

source ./utils.sh

# The unit test needs to rely on the common library functions defined in kblib.
# Therefore, we first dynamically generate the required common library files from the kblib library chart.
common_library_file="./common.sh"
generate_common_library $common_library_file

Describe "Redis Sentinel Member Leave Script Tests"

  Include ../scripts/redis-sentinel-member-leave.sh
  Include $common_library_file

  setup() {
    export KB_LEAVE_MEMBER_POD_FQDN="127.0.0.3"
    export KB_LEAVE_MEMBER_POD_NAME="sentinel-2"
    export SENTINEL_POD_FQDN_LIST="sentinel-0.redis-sentinel-headless,sentinel-1.redis-sentinel-headless,sentinel-2.redis-sentinel-headless"
    export SENTINEL_PASSWORD="sentinel_password"
    sentinel_leave_member_name=""
    sentinel_leave_member_fqdn=""
    sentinel_pod_list=()
    # set ut_mode to true to hack control flow in the script
    ut_mode="true"
  }
  BeforeAll "setup"

  cleanup() {
    unset KB_LEAVE_MEMBER_POD_FQDN
    unset KB_LEAVE_MEMBER_POD_NAME
    unset SENTINEL_POD_FQDN_LIS
    unset SENTINEL_PASSWORD
    unset sentinel_leave_member_name
    unset sentinel_leave_member_fqdn
    unset sentinel_pod_list
    rm -f $common_library_file;
  }
  AfterAll "cleanup"

  Describe "redis_sentinel_member_get function"
    It "correctly sets the sentinel leave member details and populates the sentinel pod list"
      When call redis_sentinel_member_get
      The variable sentinel_leave_member_name should eq "sentinel-2"
      The variable sentinel_leave_member_fqdn should eq "127.0.0.3"

      The variable sentinel_pod_list[0] should eq "sentinel-0.redis-sentinel-headless"
      The variable sentinel_pod_list[1] should eq "sentinel-1.redis-sentinel-headless"
      The variable sentinel_pod_list[2] should eq "sentinel-2.redis-sentinel-headless"
    End
  End

  Describe "redis_sentinel_remove_monitor function"
    It "when one master are disconnected"
      redis_sentinel_get_masters() {
        temp_output="flags
        master,disconnected"
      }
      When call redis_sentinel_remove_monitor
      The stdout should include "one or more masters are disconnected"
    End 
  End

  Describe "check_all_sentinel_agreement function"
      setup() {
        sentinel_pod_list=("sentinel-0.redis-sentinel-headless:26379" "sentinel-1.redis-sentinel-headless:26379" "sentinel-2.redis-sentinel-headless:26379")
      }
      Before 'setup'

      un_setup() {
        unset sentinel_pod_list
      }
      After 'un_setup'

      It "when one master are disconnected"
        redis_sentinel_get_masters() {
          temp_output="flags
          master,disconnected"
        }
        When call check_all_sentinel_agreement
        The stdout should include "one or more masters are disconnected"
      End 

      It "when the number of slaves are the same"
        redis_sentinel_get_masters() {
          temp_output="name
          mymaster
          flags
          master
          num-other-sentinels
          1"
        }
        When call check_all_sentinel_agreement
        The stdout should include "all masters are reachable"
        The stdout should include "all the sentinels agree about the number of sentinels currently active"
      End

  End
End