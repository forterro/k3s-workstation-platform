{{- if not (hasPrefix "6.0" $.SERVICE_VERSION) }}
bind * -::*
set-proc-title yes
proc-title-template "{title} {listen-addr} {server-mode}"
ignore-warnings ARM64-COW-BUG
lazyfree-lazy-user-del no
lazyfree-lazy-user-flush no
oom-score-adj no
oom-score-adj-values 0 200 800
disable-thp yes
{{- else }}
bind 0.0.0.0
{{- end }}
tcp-backlog 511
timeout 0
tcp-keepalive 300
daemonize no
pidfile /var/run/redis_6379.pid
{{ block "logsBlock" . }}
loglevel notice
logfile "/data/running.log"
{{ end }}
databases 16
always-show-logo no
stop-writes-on-bgsave-error yes
rdbcompression yes
rdbchecksum yes
dbfilename dump.rdb
rdb-del-sync-files no
dir /data
replica-serve-stale-data yes
replica-read-only yes
repl-diskless-sync no
repl-diskless-sync-delay 5
repl-diskless-load disabled
repl-disable-tcp-nodelay no
replica-priority 100
acllog-max-len 128
lazyfree-lazy-eviction no
lazyfree-lazy-expire no
lazyfree-lazy-server-del no
replica-lazy-flush no
appendonly yes
appendfilename "appendonly.aof"
appendfsync everysec
no-appendfsync-on-rewrite no
auto-aof-rewrite-percentage 100
auto-aof-rewrite-min-size 64mb
aof-load-truncated yes
aof-use-rdb-preamble yes
lua-time-limit 5000
slowlog-log-slower-than 10000
slowlog-max-len 128
latency-monitor-threshold 0
notify-keyspace-events ""
hash-max-ziplist-entries 512
hash-max-ziplist-value 64
list-max-ziplist-size -2
list-compress-depth 0
set-max-intset-entries 512
zset-max-ziplist-entries 128
zset-max-ziplist-value 64
hll-sparse-max-bytes 3000
stream-node-max-bytes 4096
stream-node-max-entries 100
activerehashing yes
client-output-buffer-limit normal 0 0 0
client-output-buffer-limit replica 256mb 64mb 60
client-output-buffer-limit pubsub 32mb 8mb 60
hz 10
dynamic-hz yes
aof-rewrite-incremental-fsync yes
rdb-save-incremental-fsync yes
jemalloc-bg-thread yes
aclfile /etc/redis/users.acl
save 3600 1 300 100 60 10000

# TODO: dynamic config for io-threads
io-threads 4
io-threads-do-reads yes

maxmemory-policy volatile-lru
# maxmemory <bytes>
{{- $request_memory := default 0 $.PHY_MEMORY | int }}
{{- if gt $request_memory 0 }}
maxmemory {{ mulf $request_memory 0.8 | int }}
{{- end -}}

